import React from 'react';
import '../styles/productsection.css';
import vela1Image from '../images/vela_1.jpg';
import vela2Image from '../images/vela_2.jpg';

function ProductSection() {
    const handleTitleClick = (productId) => {
    };

    return (
        <section className="product-section">
            <div className="product-grid">
                <div className="product-item" onClick={() => handleTitleClick(1)}>
                    <img src={vela1Image} alt="Vela 1" />
                    <h3>Vela 1</h3>
                    <p>Descripción del Producto 1</p>
                </div>
                <div className="product-item" onClick={() => handleTitleClick(2)}>
                    <img src={vela2Image} alt="Vela 2" />
                    <h3>Vela 2</h3>
                    <p>Descripción del Producto 2</p>
                </div>
            </div>
        </section>
    );
}

export default ProductSection;