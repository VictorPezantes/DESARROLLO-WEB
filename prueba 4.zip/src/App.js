import logo from './logo.svg';
import './App.css';
import Footer from './componentes/Footer';
import Cuerpoppal from './componentes/Cuerpoppal';
import ContactForm from './componentes/ContactForm';
import Navbar from './componentes/Navbar';
import ProductSection from './componentes/ProductSection';

function App() {
  return (
    <div className="App">
      <Navbar/>
      <Cuerpoppal/>
      <ProductSection/> 
      <ContactForm/>
      <Footer/>
    </div>
  );
}

export default App;
