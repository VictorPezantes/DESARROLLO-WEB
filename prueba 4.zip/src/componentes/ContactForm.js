import React from 'react'

const ContactForm = () => {
    function validarFormulario() {

        var nombre = document.getElementById("nombre").value;
        var correo = document.getElementById("correo").value;
        var contrasena = document.getElementById("contrasena").value;

        if (nombre === "" || correo === "" || contrasena === "") {
            document.getElementById("mensaje").textContent = "Por favor completa todos los campos.";
            return false; // Evita que el formulario se envíe
        }
        else {
            alert("Formulario enviado")
        }
        return false;
    }

    return (


        <div clase= "divformulario">
            <h1>Formulario de Registro</h1>

            <form id="formulario">
                <label for="nombre">Nombre:</label>
                <input type="text" id="nombre" name="nombre" required/>

                <label for="correo">Correo Electrónico:</label>
                <input type="email" id="correo" name="correo" />

                <label for="contrasena">Contraseña:</label>
                <input type="password" id="contrasena" name="contrasena" />
            </form>
            <button onClick={() => validarFormulario()}>Enviar</button>
            <p id="mensaje"></p>

        </div>
    )
}

export default ContactForm;
