import React from 'react'

const Cuerpoppal = () => {
    function cambiofondo() {
        document.getElementById("principal").style.backgroundColor= "lightcoral"  };
    
  return (
    <div>
      <main id="principal" onClick={ ()=> cambiofondo()}>
        <h2>Nuestra Pagina Web</h2>
        <p>Aqui hay un parrafo que supuestamente habla de nosotros</p>
        <div>
        <ul>
            <li>Elemento 1</li>
            <li>Elemento 2</li>
            <li>Elemento 3</li>
            <li>Elemento 4</li>
        </ul>
        </div>
      </main>
    </div>
  )
}

export default Cuerpoppal
