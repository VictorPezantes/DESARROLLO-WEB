import React from 'react'
import Facebook from "../Imagenes/facebook.png"
import Whatsapp from "../Imagenes/whatsapp.jpg"
import Instagram from "../Imagenes/instagram.jpg"

const Footer = () => {

  function ingresarmouse() {
    document.getElementById('cambiofuente').style.fontStyle = "italic";
    document.getElementById('cambiofuente').style.fontWeight = "900";
  }

  function cambiocolor() {
    document.getElementById('footer').style.backgroundColor = "cyan";
  }

  function desvanecer(parametro) {
    console.log(parametro)
    switch (parametro) {
      case "Facebook":
        document.getElementById("desvanecer1").style.opacity = "0";
        window.open("https://www.facebook.com/", '_blank');
        break;
      case "Whatsapp":
        document.getElementById("desvanecer2").style.opacity = "0";
        window.open("https://web.whatsapp.com/", '_blank');
        break;
      case "instagram":
        document.getElementById("desvanecer3").style.opacity = "0";
        window.open("https://www.instagram.com/", '_blank');
        break;
      default:
        break;
      // document.getElementById("desvanecer").style.opacity = "0";
    }
  }

  return (
    <div>

      <footer class="footer" id="footer" onMouseOver={cambiocolor}>
        <div>
          <p id="cambiofuente" onMouseOver={ingresarmouse}>Esta pagina es autoria de Marco Ojeda y Luz Maria Cabezas</p>

          <ul>
            <li><a id="desvanecer1"  >
              <img onClick={() => desvanecer("Facebook")} class="icono" border="0" alt="Facebook" src={Facebook} width="100" height="100" />
            </a></li>
            <li><a id="desvanecer2" >
              <img onClick={() => desvanecer("Whatsapp")} class="icono" border="0" alt="Whatsapp" src={Whatsapp} width="100" height="100" />
            </a></li>
            <li><a id="desvanecer3"  >
              <img onClick={() => desvanecer("instagram")} class="icono" border="0" alt="Instagram" src={Instagram} width="100" height="100" />
            </a></li>
          </ul>
        </div>
      </footer>

    </div>
  )
}

export default Footer
