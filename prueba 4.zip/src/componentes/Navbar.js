const Navbar = () => {

    function ingresarmouse() {
      document.getElementById('cambiocolor').style.fontStyle = "italic"
  }
  
return ( 

  <>
      <header>
        <h1 id="cambiocolor" onMouseOver={ingresarmouse}>MarxLux</h1>
        <nav id="menu">
          <ol>
            <li><a href="#">Contact Us0</a></li>
            <li><a href="#">Contact Us1</a></li>
            <li><a href="#">Contact Us2</a></li>
            <li><a href="#">Contact Us3</a></li>
          </ol>
        </nav>
      </header>

      <hr></hr>

  </>  
  )
}
export default Navbar
