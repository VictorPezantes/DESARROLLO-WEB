import imagen from "../Imagenes/falda1.jpeg"
import imagen1 from "../Imagenes/falda2.jpeg"
import imagen2 from "../Imagenes/falda3.jpeg"

//import imagen from "../Imagenes/react.png" //importar imagenes


const ProductSection = () => {

    function ingresarmouse() {
      document.getElementById('cambiocolor').style.fontStyle = "italic"
  }
  
return ( 

  <>
  <section>

  
   <div id="lista">
    <img src={imagen} alt="" />
    <h3>Falda Tubo</h3>
    <p></p>
    </div>
    <div id="lista1">
    <img src={imagen1} alt="" />
    <h3>Falda Plisada</h3>
    <p></p>
    </div>
    <div id="lista2">
    <img src={imagen2} alt="" />
    <h3>Falda Escocesa</h3>
    <p></p>
    </div>
    
 
</section>

  </>  
  )
}
export default ProductSection
